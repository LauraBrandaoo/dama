import React from 'react'
import { StyleSheet, View} from 'react-native'

const BlocoScreen = () => {
    return (
        <View style={styles.mainView}>
            <View style={styles.main}/>
            <View style={styles.main}/>
            <View style={styles.main}/>  
        </View>
    )
}

const styles = StyleSheet.create({
    mainView: {
        justifyContent: 'space-around',
        padding: 10

    },
    main: {
        backgroundColor: "#ffb6c1",
        width: 50,
        height: 50
    }
})

export default BlocoScreen