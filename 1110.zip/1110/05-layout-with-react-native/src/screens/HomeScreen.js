import React from 'react'
import { StyleSheet, View, Button } from 'react-native'

const HomeScreen = (props) => {
    const navigation = props.navigation

    return (
        <View style={styles.mainView}>
            <View style={styles.mainButton}>
                <Button
                onPress={() => { navigation.navigate('Box') }}
                title="Go to Box Screen" />
            </View>
            <View style={styles.mainButton}>
                <Button
                onPress={() => { navigation.navigate('FlexBox') }}
                title="Go to FlexBox Screen" />
            </View>
            <View style={styles.mainButton}>
                <Button
                onPress={() => { navigation.navigate('Position') }}
                title="Go to Position Screen" />
            </View>  
            <View style={styles.mainButton}>
                <Button
                onPress={() => { navigation.navigate('App') }}
                title="Go to App Screen" />
            </View>  
        </View>
    )
}

const styles = StyleSheet.create({
    mainView: {
        justifyContent: 'space-around',
        padding: 10

    },
    mainButton: {
        marginVertical: 10
    }
})

export default HomeScreen